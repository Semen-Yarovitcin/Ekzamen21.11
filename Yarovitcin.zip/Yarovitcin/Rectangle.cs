using System;

class Rectangle
{
    double width;
    double length;

    public Rectangle(double w, double l)
    {
        width = w;
        length = l;
    }

    public double Area()
    {
        return width * length;
    }

    public double Perimeter()
    {
        return 2 * (width + length);
    }
}

class Program
{
    static void Main()
    {
        Rectangle r = new Rectangle(5, 10);

        Console.WriteLine("Площадь: " + r.Area());
        Console.WriteLine("Периметр: " + r.Perimeter());
    }
}